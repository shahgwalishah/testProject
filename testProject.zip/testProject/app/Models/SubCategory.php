<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SubCategory extends Model
{
    use HasFactory;
    protected $fillable = [
        'category_id','name'
    ];
    public function categories() {
        return $this->hasMany(Category::class , 'id' ,'categorie_id');
    }
    public static function SaveSubCategory($request) {
        try {
            self::create([
                'category_id' => $request['category_id'],
                'name' => $request['name'],
            ]);
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}
