<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\SubCategory;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    public function addCategory() {
        $category = Category::with('sub_categories')->get();
        $sub_category = SubCategory::with('categories')->get();
        return view('category',[
            'category' => $category,
            'sub_category' => $sub_category
        ]);
    }

    public function saveCategory(Request $request) {
        if(Category::SaveCategory($request->all())) {
            return back()->with('success' , 'Category Saved Successfully .. !');
        } else {
            return back()->with('error' , 'Something Went Wrong .. !');
        }
    }
}
