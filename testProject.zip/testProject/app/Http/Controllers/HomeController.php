<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
//        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('backend.index');
    }
    public function dashboard()
    {
        return view('backend.index');
    }
    public function resetPassowrd($code)
    {
        $check = User::where('verification_code','=',$code)->first();
        if(is_null($check)){
            return abort(419);
        } else {
            return view('reset-password',[
                'user' => $check
            ]);
        }
    }
    public function userResetPassword(Request $request)
    {
        User::where('id','=',$request->user_id)->update([
            'password' => bcrypt($request->password),
            'verification_code' => null
        ]);
        return collect([
            'status' => true,
            'message' => 'password reset successfully'
        ]);
    }
}
