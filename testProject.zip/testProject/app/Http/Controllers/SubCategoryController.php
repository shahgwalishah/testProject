<?php

namespace App\Http\Controllers;

use App\Models\SubCategory;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    public function storeSubCategory(Request $request) {
        if(SubCategory::SaveSubCategory($request->all())) {
            return back()->with('success','Sub Category Saved Successfully ... !');
        }   else {
            return back()->with('error','Something Wrong ... !');
        }
    }
}
