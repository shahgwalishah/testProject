<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Category</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h2>Add Category</h2>
    <br>
    <form action="<?php echo e(route('saveCategory')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email">Category:</label>
            <input type="text" class="form-control" id="email" placeholder="Enter category name" name="name">
        </div>
        <button type="submit" class="btn btn-success">Submit Category</button>
    </form>
    <br>
    <h2>Table</h2>
    <table class="table">
        <thead>
        <tr>
            <th>#</th>
            <th>Category</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($cat->id); ?></td>
                <td><?php echo e($cat->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
    <h2>Add Sub Category</h2>
    <br>
    <form action="<?php echo e(route('storeSubCategory')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="email">Select Category:</label>
            <select class="form-control" name="category_id">
                <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="email">SubCategory:</label>
            <input type="text" class="form-control" id="email" placeholder="Enter category name" name="name">
        </div>
        <button type="submit" class="btn btn-success">Submit Sub Category</button>
    </form>
    <br>
    <h2>Table</h2>
    <table class="table">
        <thead>
        <tr>
            <th>#</th>
            <th>Sub Category</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $sub_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subCat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($subCat->id); ?></td>
                <td><?php echo e($subCat->name); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <br>
    <br>
</div>

</body>
</html>
<?php /**PATH /home/wali/Desktop/workspace/testProject/resources/views/category.blade.php ENDPATH**/ ?>