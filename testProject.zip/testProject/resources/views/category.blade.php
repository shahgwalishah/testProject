<!DOCTYPE html>
<html lang="en">
<head>
    <title>Add Category</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
    <h2>Add Category</h2>
    <br>
    <form action="{{route('saveCategory')}}">
        @csrf
        <div class="form-group">
            <label for="email">Category:</label>
            <input type="text" class="form-control" id="email" placeholder="Enter category name" name="name">
        </div>
        <button type="submit" class="btn btn-success">Submit Category</button>
    </form>
    <br>
    <h2>Table</h2>
    <table class="table">
        <thead>
        <tr>
            <th>#</th>
            <th>Category</th>
        </tr>
        </thead>
        <tbody>
        @foreach($category  as $cat)
            <tr>
                <td>{{$cat->id}}</td>
                <td>{{$cat->name}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <br>
    <br>
    <h2>Add Sub Category</h2>
    <br>
    <form action="{{route('storeSubCategory')}}">
        @csrf
        <div class="form-group">
            <label for="email">Select Category:</label>
            <select class="form-control" name="category_id">
                @foreach($category as $cat)
                    <option value="{{$cat->id}}">{{$cat->name}}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="email">SubCategory:</label>
            <input type="text" class="form-control" id="email" placeholder="Enter category name" name="name">
        </div>
        <button type="submit" class="btn btn-success">Submit Sub Category</button>
    </form>
    <br>
    <h2>Table</h2>
    <table class="table">
        <thead>
        <tr>
            <th>#</th>
            <th>Sub Category</th>
        </tr>
        </thead>
        <tbody>
        @foreach($sub_category  as $subCat)
            <tr>
                <td>{{$subCat->id}}</td>
                <td>{{$subCat->name}}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <br>
    <br>
</div>

</body>
</html>
